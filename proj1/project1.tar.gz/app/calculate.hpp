#ifndef CALCULATE_HPP
#define CALCULATE_HPP

double calculate_distance(double lat1, double lat2, double lon1, double lon2);

#endif
