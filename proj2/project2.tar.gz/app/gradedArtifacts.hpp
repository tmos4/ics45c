#ifndef GRADED_ARTIFACTS
#define GRADED_ARTIFACTS

int* getGradedArtifacts(int number);

#endif
