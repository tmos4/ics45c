#ifndef CUTPOINT_SETS
#define CUTPOINT_SETS

double* getCutpointSet();
void calculateGrades(Student* students, double* cutpointSet, int n);
void printGrades(Student* students, int n2, int a);

#endif
