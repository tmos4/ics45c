#ifndef SCORES
#define SCORES

void getScores(Student* students, int n0, int n2);
double calculateScore(int* possibleScores, int* weights, Student student, int n);
void printTotalScores(Student* students,int n);

#endif
